// Listen for the scrape request
const scrapeForm = document.querySelector('form') || document.body;

scrapeForm.addEventListener('submit', async (e) => {
    // 1. STOP THE PAGE REFRESH IMMEDIATELY
    e.preventDefault(); 
    
    // 2. READ THE FIELDS
    const industryInput = document.querySelector('input[placeholder*="Industry"]') || document.querySelectorAll('input')[0];
    const cityInput = document.querySelector('input[placeholder*="City"]') || document.querySelectorAll('input')[1];
    const feedIndicator = document.querySelector('.channels-active') || document.body;

    const industry = industryInput ? industryInput.value.trim() : '';
    const city = cityInput ? cityInput.value.trim() : '';

    if (!industry || !city) {
        alert("Please enter both target variables.");
        return;
    }

    try {
        if(feedIndicator) feedIndicator.innerText = "Processing streams...";
        
        // 3. TARGET YOUR LIVE PRODUCTION ENDPOINT DIRECTLY
        const response = await fetch('https://onrender.com', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ industry, city })
        });

        const data = await response.json();
        console.log("Response data returned:", data);

        if (data.leads && data.leads.length > 0) {
            alert(`Success! Loaded ${data.leads.length} lead profiles.`);
            // Your custom card rendering layout engine can process data fields here
        } else {
            alert("API connection functional, but no businesses matched your query parameters.");
        }
    } catch (error) {
        console.error("Connection failure:", error);
        alert("Failed to reach server node.");
    }
});
