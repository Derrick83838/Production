document.addEventListener('DOMContentLoaded', () => {
    const scrapeForm = document.querySelector('form') || document.body;

    scrapeForm.addEventListener('submit', async (e) => {
        // 1. STOP THE HARD PAGE RELOAD
        e.preventDefault(); 

        // 2. TARGET FIELDS SECURELY BY CAPTURING USER INPUTS
        const inputs = document.querySelectorAll('input');
        const industryInput = inputs[0];
        const cityInput = inputs[1];
        
        // Target indicators by structural status strings
        const feedLabel = document.querySelector('.channels-active') || document.body;

        const industry = industryInput ? industryInput.value.trim() : '';
        const city = cityInput ? cityInput.value.trim() : '';

        if (!industry || !city) {
            alert("Please fill in both input parameters before scraping.");
            return;
        }

        try {
            console.log(`Sending target requests: Industry: ${industry}, City: ${city}`);
            
            // 3. TARGET THE CORRECT LIVE RENDER DOMAIN VIA POST REQUESTS
            const response = await fetch('https://onrender.com', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ industry, city })
            });

            if (!response.ok) {
                throw new Error(`Server returned error status code: ${response.status}`);
            }

            const data = await response.json();
            console.log("Leads payload successfully extracted:", data);

            if (data.leads && data.leads.length > 0) {
                alert(`Success! Found ${data.leads.length} live lead structures near ${city}.`);
                // Custom frontend layout loops can dynamically insert blocks here
            } else {
                alert("Connection successful, but zero data parameters matched this specific geographical layout.");
            }

        } catch (error) {
            console.error("Critical stream extraction error:", error);
            alert("Network connection error. Check your server pipeline layout logs.");
        }
    });
});
