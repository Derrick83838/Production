document.addEventListener("DOMContentLoaded", () => {
    const scrapeButton = document.querySelector(".btn-scrape");
    const leadFeedContainer = document.getElementById("leadFeedContainer");
    const leadCountBadge = document.getElementById("leadCountBadge");
    const emailOutput = document.getElementById("emailOutput");
    const terminalCompanyName = document.getElementById("terminalCompanyName");
    const extractedUpdateText = document.getElementById("extractedUpdateText");

    scrapeButton.addEventListener("click", async () => {
        const industryInput = document.getElementById("industryInput").value.trim();
        const cityInput = document.getElementById("cityInput").value.trim();
        
        if (!industryInput || !cityInput) {
            alert("Please type a valid target industry and geographic city first.");
            return;
        }

        scrapeButton.innerText = "⚡ PROBING MAPS & RUNNING AI PIPELINES...";
        scrapeButton.disabled = true;
        scrapeButton.style.opacity = "0.5";
        
        try {
            // Live production fetch call to your Render back-end server endpoint
            const response = await fetch('/api/scrape', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ industry: industryInput, city: cityInput })
            });

            const data = await response.json();
            
            // Clear existing panels completely
            leadFeedContainer.innerHTML = "";

            if (!data.leads || data.leads.length === 0) {
                leadCountBadge.innerText = `0 channels active`;
                leadFeedContainer.innerHTML = `
                    <div class="empty-state-msg">
                        <div class="empty-icon">⚠️</div>
                        <p>No verified commercial matches found on Google Maps for your specific query.</p>
                    </div>
                `;
                return;
            }

            // Sync structural dashboard counts
            leadCountBadge.innerText = `${data.leads.length} data streams verified`;

            // Dynamically output the live incoming API lead objects
            data.leads.forEach(lead => {
                const cardHTML = document.createElement("div");
                cardHTML.className = "lead-card";
                cardHTML.innerHTML = `
                    <div class="lead-header">
                        <div>
                            <h3>${lead.name}</h3>
                            <a href="#" class="lead-link" target="_blank">${lead.url}</a>
                            <p class="lead-email">✉ ${lead.email}</p>
                        </div>
                        <button class="btn-action">✨ AI Personalize</button>
                    </div>
                    <div class="match-box">
                        <span class="match-label">LIVE TRACK MATCH:</span>
                        <p class="match-text">${lead.match}</p>
                    </div>
                `;
                leadFeedContainer.appendChild(cardHTML);
            });

            // Re-arm interactive events
            bindPersonalizationButtons();

        } catch (err) {
            console.error("Pipeline Sync Error:", err);
            alert("Critical Network Timeout. Verify that your environment variable parameters match on Render.");
        } finally {
            scrapeButton.innerText = "Scrape Live Leads";
            scrapeButton.disabled = false;
            scrapeButton.style.opacity = "1";
        }
    });

    function bindPersonalizationButtons() {
        const freshButtons = document.querySelectorAll(".btn-action");
        freshButtons.forEach(button => {
            button.addEventListener("click", (e) => {
                const leadCard = e.target.closest(".lead-card");
                const companyName = leadCard.querySelector("h3").innerText;
                const companyMatch = leadCard.querySelector(".match-text").innerText;
                
                // Clear placeholder styling instantly on click
                emailOutput.classList.remove("placeholder-text");
                extractedUpdateText.classList.remove("placeholder-text");
                
                // Set text values
                terminalCompanyName.innerText = companyName;
                extractedUpdateText.innerText = companyMatch;
                
                // Compute professional business text values
                emailOutput.innerHTML = `
                    <strong>Subject:</strong> Strategic optimization thesis for ${companyName}<br><br>
                    Hi Team,<br><br>
                    I was analyzing market components inside your region when our metrics prioritized your operations footprint.<br><br>
                    Our audit track flagged an addressable workflow friction point: <strong>${companyMatch}</strong><br><br>
                    We built a specialized engine engineered precisely to handle this. Do you have 5 minutes for a brief call later this week?
                `;
                
                if (window.innerWidth < 768) {
                    emailOutput.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }
});
