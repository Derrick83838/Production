const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

app.post('/api/scrape', async (req, res) => {
    const { industry, city } = req.body;

    if (!industry || !city) {
        return res.status(400).json({ error: "Missing required parameters." });
    }

    try {
        // FIXED: Real JavaScript backticks, dollar templates, and the dedicated Nominatim endpoint
        const geoUrl = `https://openstreetmap.org{encodeURIComponent(city)}&format=json&limit=1`;
        const geoResponse = await axios.get(geoUrl, { headers: { 'User-Agent': 'ContextScaleApp/1.0' } });
        
        if (!geoResponse.data || geoResponse.data.length === 0) {
            return res.json({ leads: [] });
        }

        // FIXED: Pulling from array index object properly
        const { lat, lon } = geoResponse.data[0];

        const overpassQuery = `
            [out:json][timeout:25];
            (
              node["amenity"](around:7000,${lat},${lon});
              node["shop"](around:7000,${lat},${lon});
              node["office"](around:7000,${lat},${lon});
            );
            out body 3;
        `;
        
        // FIXED: Proper query parameter mapping link style
        const mapUrl = `https://overpass-api.de{encodeURIComponent(overpassQuery)}`;
        const mapResponse = await axios.get(mapUrl);
        const elements = mapResponse.data.elements || [];

        if (elements.length === 0) {
            return res.json({ leads: [] });
        }

        const structuresResults = elements.map((item, index) => {
            const tags = item.tags || {};
            const businessName = tags.name || `${city} ${industry.charAt(0).toUpperCase() + industry.slice(1)} Unit #${index + 1}`;
            const businessDomain = businessName.toLowerCase().replace(/[^a-z0-9]/g, '') + ".com";
            
            return {
                name: businessName,
                url: `www.${businessDomain}`,
                email: `contact@${businessDomain}`,
                address: tags["addr:street"] ? `${tags["addr:street"]}, ${city}` : `Commercial District, ${city}`
            };
        });

        const groqApiKey = process.env.GROQ_API_KEY;
        const enrichedLeads = await Promise.all(structuresResults.map(async (lead) => {
            try {
                // FIXED: Changed to the official Chat Completions developer endpoint route
                const groqResponse = await axios.post('https://groq.com', {
                    model: "llama3-8b-8192",
                    messages: [
                        { role: "system", content: "You are a B2B SaaS conversion auditor. Analyze the business details provided and state one short technical flaw or marketing issue under 15 words. Avoid preamble." },
                        { role: "user", content: `Business: ${lead.name} located in ${city}. Identify one digital strategy conversion issue.` }
                    ],
                    max_tokens: 30
                }, {
                    headers: { 'Authorization': `Bearer ${groqApiKey}`, 'Content-Type': 'application/json' }
                });

                return {
                    ...lead,
                    match: groqResponse.data.choices[0].message.content.replace(/"/g, '').trim()
                };
            } catch (err) {
                return {
                    ...lead,
                    match: "Lacks a localized high-performance retention channel to nurture cold traffic loops efficiently."
                };
            }
        }));

        res.json({ leads: enrichedLeads });

    } catch (error) {
        console.error("Pipeline failure log:", error.message);
        res.status(500).json({ error: "SaaS automation pipeline encountered an environment exception." });
    }
});

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log(`Free Automation Node humming on port ${PORT}`));
