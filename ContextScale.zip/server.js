const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { OpenAI } = require('openai');

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend files from your folder root
app.use(express.static(__dirname));

// Initialize OpenAI client using secure server environments
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// THE AUTOMATED SCRAPE PIPELINE
app.post('/api/scrape', async (req, res) => {
    const { industry, city } = req.body;

    if (!industry || !city) {
        return res.status(400).json({ error: "Missing industry or city parameters" });
    }

    try {
        const googleApiKey = process.env.GOOGLE_MAPS_API_KEY;
        const searchQuery = `${industry} in ${city}`;
        
        // 1. CALL GOOGLE PLACES API TO SCRAPE REAL BUSINESSES
        const googleUrl = `https://googleapis.com{encodeURIComponent(searchQuery)}&key=${googleApiKey}`;
        const googleResponse = await axios.get(googleUrl);
        
        const rawPlaces = googleResponse.data.results || [];
        
        // Take the top 3 live business results to optimize performance
        const structuresResults = rawPlaces.slice(0, 3).map(place => ({
            name: place.name,
            address: place.formatted_address || "Local Area",
            // Fallback mock site/email defaults if Google does not have them public
            url: place.website || `www.${place.name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
            email: `info@${place.name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`
        }));

        if (structuresResults.length === 0) {
            return res.json({ leads: [] });
        }

        // 2. CONCURRENTLY ENRICH EACH LEAD VIA OPENAI TO FIND COLD ANGLES
        const enrichedLeads = await Promise.all(structuresResults.map(async (lead) => {
            try {
                const aiResponse = await openai.chat.completions.create({
                    model: "gpt-4o-mini",
                    messages: [
                        { 
                            role: "system", 
                            content: "You are a B2B conversion strategist. Analyze a business profile and generate a highly specific conversion mismatch or hook. Keep it concise under 20 words." 
                        },
                        { 
                            role: "user", 
                            content: `Business: ${lead.name}. Address: ${lead.address}. Identify an audit track angle for outreach.` 
                        }
                    ],
                    max_tokens: 40
                });

                return {
                    ...lead,
                    match: aiResponse.choices[0].message.content.replace(/"/g, '')
                };
            } catch (aiErr) {
                return {
                    ...lead,
                    match: "Looking for optimized cold outreach solutions to expand geographic operations this quarter."
                };
            }
        }));

        res.json({ leads: enrichedLeads });

    } catch (error) {
        console.error("Pipeline failure:", error.message);
        res.status(500).json({ error: "Internal automation server failed to parse queries." });
    }
});

// Start the production network port listener
const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log(`SaaS Engine humming on port ${PORT}`));
